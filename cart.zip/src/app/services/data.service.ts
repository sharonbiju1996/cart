import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  private cartItems = new BehaviorSubject<number>(0);

  castCartItem = this.cartItems.asObservable()

  constructor() { }
  
  editCartItems(cart){
    this.cartItems.next(cart);
  }
}
