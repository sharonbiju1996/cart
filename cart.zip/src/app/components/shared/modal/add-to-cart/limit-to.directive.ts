import { Directive,ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appLimitTo]'
})
export class LimitToDirective {

  @Input('appLimitTo') limitTo: number=1;
  constructor(private el: ElementRef) { }
  @HostListener('keydown.backspace', ['$event'])
  onKeyDown(evt: KeyboardEvent) {
    let a = (evt.target as HTMLInputElement).value.length; 

    
     if (a <= this.limitTo) {
    
      evt.preventDefault();
    }
   
  }

}
