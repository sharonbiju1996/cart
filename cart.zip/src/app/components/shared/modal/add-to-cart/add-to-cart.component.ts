
import { Component, OnInit,Inject,ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import {FormControl,FormBuilder, Validators, FormGroup} from '@angular/forms';
import { DataService } from './../../../../services/data.service';


@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit {

  constructor(
     public hostElement: ElementRef,
     public dialogRef: MatDialogRef<AddToCartComponent>,
    public router: Router,
    private dataService : DataService,
    // private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data,private fb: FormBuilder) { 
    
  }

  strSize = '250G';
  intQuantity = 1;
  addCartForm;

  currentCartItem ;

  ngOnInit(): void {
    this.addCartForm = this.fb.group({
      size: ['', Validators.required],
      quantity: ['', Validators.required]
    });

    this.dataService.castCartItem.subscribe(cartItem => 
      this.currentCartItem = cartItem
      );

    
  }

  closeAddCart(){
    this.dialogRef.close();

  }
  addtoCart(){
    window.alert('item added to cart');
    this.dataService.editCartItems(this.currentCartItem + 1);
    this.dialogRef.close()
  }
  hideZero(){
    if(this.intQuantity == 0 ){
      this.intQuantity = 1;
  }
  }

}
