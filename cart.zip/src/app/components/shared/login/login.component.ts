import { SignupComponent } from './../signup/signup.component';
import { Component, OnInit,Inject,ElementRef,HostListener } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA,MatDialog} from '@angular/material/dialog';
import { Router } from '@angular/router';
import {FormControl,FormBuilder, Validators, FormGroup} from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  @HostListener('document:click', ['$event'])
  clickout(event) {
    if (this.signupclickoutHandler) {
      this.signupclickoutHandler(event);
    }
  }

  signupclickoutHandler: Function;

  signupDialogRef: MatDialogRef<SignupComponent>;

  // showLogin = true;
  showSignuP = false;

  constructor(
    public hostElement: ElementRef,
    public dialogRef: MatDialogRef<LoginComponent>,
    // public signupDialogRef: MatDialogRef<SignupComponent>,
    public router: Router,
    public dialog: MatDialog,
    // private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data,private fb: FormBuilder) { }

  strUsername = '';
  strPassword ='';

  strFirstName = '';
  strLastname = '';
  strEmail= '';
  strMobile= '';
  strpassword= '';
  strConfirmPassword= '';

  loginForm;
  signUpForm;

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.signUpForm = this.fb.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email:[''],
      mobile: ['', Validators.required],
      choosepass:['', Validators.required],
      confirmpass:['', Validators.required],

    });
  }
  Login(){

  }
  signUp(){

  }




}
