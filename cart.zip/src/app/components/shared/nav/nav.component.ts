
import { Component, OnInit,HostListener } from '@angular/core';
import { MatDialog ,MatDialogRef} from '@angular/material/dialog';
import { LoginComponent } from './../login/login.component';
import { DataService } from './../../../services/data.service';


@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  itemsInCart = 5;

  @HostListener('document:click', ['$event'])
  clickout(event) {
    if (this.clickoutHandler) {
      this.clickoutHandler(event);
    }
  }

  constructor(public dialog: MatDialog, private dataService : DataService) { }

  blnMobileSidebar = false;

  clickoutHandler: Function;

  dialogRef: MatDialogRef<LoginComponent>;

  ngOnInit(): void {

    this.dataService.castCartItem.subscribe(cart=>
      this.itemsInCart = cart
      );
  }

  mobileSidebarClick(){
    this.blnMobileSidebar = !this.blnMobileSidebar;
  }
  Login() {
    var containerElement = document.getElementById('main');
    
    containerElement.setAttribute('class', 'blur');
     this.dialogRef = this.dialog.open(LoginComponent, {
      disableClose: true,
      width: '500px',
      height: 'auto',
      maxHeight:'80vh',
      panelClass: 'custom-dialog',
    
     
      // data: { 'item': item,}
    });
    
    this.dialogRef.afterOpened().subscribe(() => {
      this.clickoutHandler = this.closeDialogFromClickout;
    });

    this.dialogRef.afterClosed().subscribe(() => {
      this.clickoutHandler = null;
      containerElement.setAttribute('class', '');
      console.log('The dialog was closed');
    });

    
  }

  closeDialogFromClickout(event: MouseEvent) {
    const matDialogContainerEl = this.dialogRef.componentInstance.hostElement.nativeElement.parentElement;
    const rect = matDialogContainerEl.getBoundingClientRect()
    if(event.clientX <= rect.left || event.clientX >= rect.right || 
        event.clientY <= rect.top || event.clientY >= rect.bottom) {
      this.dialogRef.close();
    }
  }


  

}
