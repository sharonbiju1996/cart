import { AddToCartComponent } from './../../shared/modal/add-to-cart/add-to-cart.component';
import { Component, OnInit,HostListener } from '@angular/core';
import { MatDialog,MatDialogRef} from '@angular/material/dialog';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  @HostListener('document:click', ['$event'])
  clickout(event) {
    if (this.clickoutHandler) {
      this.clickoutHandler(event);
    }
  }

  clickoutHandler: Function;
  dialogRef: MatDialogRef<AddToCartComponent>;

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  addtoCart(item) {
     this.dialogRef = this.dialog.open(AddToCartComponent, {
      disableClose: true,
      width: '900px',
      height: '620px',
      maxHeight: '90vh',
      data: { 'item': item,}
    });

    this.dialogRef.afterOpened().subscribe(() => {
      this.clickoutHandler = this.closeDialogFromClickout;
    });

    this.dialogRef.afterClosed().subscribe(() => {
      this.clickoutHandler = null;
    });
  }

  closeDialogFromClickout(event: MouseEvent) {
    const matDialogContainerEl = this.dialogRef.componentInstance.hostElement.nativeElement.parentElement;
    const rect = matDialogContainerEl.getBoundingClientRect()
    if(event.clientX <= rect.left || event.clientX >= rect.right || 
        event.clientY <= rect.top || event.clientY >= rect.bottom) {
      this.dialogRef.close();
    }
  }

}
